package Bank.Oberserver;

public interface DisplayDetail {
    public void display();
}
