package Bank.Oberserver;

public interface Customer {
    public void update(double stockIndex);
}
