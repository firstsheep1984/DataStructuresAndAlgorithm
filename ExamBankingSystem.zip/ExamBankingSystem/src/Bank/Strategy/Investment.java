package Bank.Strategy;

public interface Investment {
    public void investmoney(double amount);
}
