package com.company;

public interface IAuto {
    public void accelerate(int s);
    public void decelerate(int s);
    public int getSpeed();
}
