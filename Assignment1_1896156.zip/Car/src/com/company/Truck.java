package com.company;

public class Truck{
    private boolean offRoad;

    public boolean getOffRoad()
    {
        return offRoad;
    }
}