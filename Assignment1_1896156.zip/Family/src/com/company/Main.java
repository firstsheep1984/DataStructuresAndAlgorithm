package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Father f = new Father(65, "male");
        System.out.println(f);
    }
}
