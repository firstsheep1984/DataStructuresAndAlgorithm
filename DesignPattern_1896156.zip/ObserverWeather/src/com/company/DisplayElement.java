package com.company;

public interface DisplayElement {
    public void display();
}
