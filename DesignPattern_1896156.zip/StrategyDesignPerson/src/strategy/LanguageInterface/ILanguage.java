package strategy.LanguageInterface;

public interface ILanguage {
    public void speak();
}
